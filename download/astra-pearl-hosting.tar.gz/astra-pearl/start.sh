#!/usr/bin/env sh
# Запуск готовой сборки. Хостеру достаточно выставить PORT и переменные окружения.
set -e
cd "$(dirname "$0")"

if [ -f .env ]; then
  set -a
  . ./.env
  set +a
fi

NODE_ENV=production
export NODE_ENV
PORT="${PORT:-3000}"
HOSTNAME="${HOSTNAME:-0.0.0.0}"
export PORT HOSTNAME
DATABASE_PATH="${DATABASE_PATH:-./data/app.db}"
export DATABASE_PATH

echo "Astra Pearl: http://${HOSTNAME}:${PORT}  (база: ${DATABASE_PATH})"
exec node server.js
