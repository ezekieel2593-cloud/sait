var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/geo/search/route.js")
R.c("server/chunks/[externals]__0u07tl7z38q4u._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_09fxyau3-c0-i._.js")
R.c("server/chunks/_next-internal_server_app_api_geo_search_route_actions_1m857n3radcrg.js")
R.m(17357)
module.exports=R.m(17357).exports
