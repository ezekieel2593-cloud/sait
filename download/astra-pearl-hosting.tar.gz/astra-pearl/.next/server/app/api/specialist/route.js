var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/specialist/route.js")
R.c("server/chunks/[externals]__0yxym3ppibqzd._.js")
R.c("server/chunks/src_lib_db_ts_12rrbm4_je1ts._.js")
R.c("server/chunks/_0htkyromubauz._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_008kzhghh6x5w._.js")
R.c("server/chunks/_next-internal_server_app_api_specialist_route_actions_1b1ogownwd_ud.js")
R.m(91594)
module.exports=R.m(91594).exports
