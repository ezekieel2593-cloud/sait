var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/specialist/logout/route.js")
R.c("server/chunks/[externals]__0yxym3ppibqzd._.js")
R.c("server/chunks/src_lib_db_ts_12rrbm4_je1ts._.js")
R.c("server/chunks/_0htkyromubauz._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/_20ddee33oq56x._.js")
R.c("server/chunks/_next-internal_server_app_api_specialist_logout_route_actions_1tuwmp6m8o7hb.js")
R.m(46620)
module.exports=R.m(46620).exports
