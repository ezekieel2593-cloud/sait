:HL["/_next/static/chunks/1bi-00794grad.css","style"]
:HC["/",""]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"matrix","h":64,"c":"$Q3"}]]
1:[["children",{"s":"(public)","h":32,"c":"$Q2"}]]
0:{"b":"0_UV-hK7ep1_B189WaEL3","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
