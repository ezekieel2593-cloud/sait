globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/0_UV-hK7ep1_B189WaEL3/_buildManifest.js",
    "static/0_UV-hK7ep1_B189WaEL3/_ssgManifest.js",
    "static/0_UV-hK7ep1_B189WaEL3/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/1-nqmp1rl8kqt.js",
    "static/chunks/3wbm-994r45kr.js",
    "static/chunks/34goyxc2anvlg.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/astrology/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/astrology/result/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/full-reading/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/matrix/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/matrix/result/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/privacy/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(public)/terms/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/specialist/(cabinet)/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/specialist/(cabinet)/knowledge/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/specialist/(cabinet)/leads/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/specialist/(cabinet)/leads/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/specialist/(cabinet)/settings/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/specialist/login/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/1-nqmp1rl8kqt.js",
        "static/chunks/3wbm-994r45kr.js",
        "static/chunks/34goyxc2anvlg.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
