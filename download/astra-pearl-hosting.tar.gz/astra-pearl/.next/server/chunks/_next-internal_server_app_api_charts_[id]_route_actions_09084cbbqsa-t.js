module.exports=[22727,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_charts_%5Bid%5D_route_actions_09084cbbqsa-t.js.map