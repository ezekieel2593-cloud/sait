module.exports=[70580,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_specialist_knowledge_route_actions_1v4vdkbge26x3.js.map