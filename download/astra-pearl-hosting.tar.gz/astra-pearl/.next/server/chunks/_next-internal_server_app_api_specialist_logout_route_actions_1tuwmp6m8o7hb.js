module.exports=[88269,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_specialist_logout_route_actions_1tuwmp6m8o7hb.js.map