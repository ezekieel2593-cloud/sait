module.exports=[13070,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_specialist_password_route_actions_0fnzooc804mv4.js.map