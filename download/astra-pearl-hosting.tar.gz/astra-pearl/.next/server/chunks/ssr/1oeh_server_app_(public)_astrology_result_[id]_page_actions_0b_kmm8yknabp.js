module.exports=[58354,a=>{"use strict";a.s([])}];

//# sourceMappingURL=1oeh_server_app_%28public%29_astrology_result_%5Bid%5D_page_actions_0b_kmm8yknabp.js.map