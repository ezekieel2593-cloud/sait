module.exports=[61469,a=>{"use strict";var b=a.x("node:sqlite",()=>require("node:sqlite"),!0),c=a.i(2157),d=a.i(50227);let e=`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'specialist',
  is_active INTEGER NOT NULL DEFAULT 1,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until TEXT,
  last_login_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  ip TEXT,
  user_agent TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS services (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  direction TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price TEXT,
  duration TEXT,
  includes TEXT NOT NULL DEFAULT '[]',
  is_active INTEGER NOT NULL DEFAULT 1,
  sort INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS calculations (
  id TEXT PRIMARY KEY,
  direction TEXT NOT NULL,
  input TEXT NOT NULL,
  result TEXT NOT NULL,
  methodology TEXT NOT NULL,
  algorithm_version TEXT NOT NULL,
  birth_date TEXT NOT NULL,
  birth_time TEXT,
  birth_place TEXT,
  timezone TEXT,
  latitude REAL,
  longitude REAL,
  time_accuracy TEXT,
  ip_hash TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_calculations_created ON calculations(created_at);

CREATE TABLE IF NOT EXISTS leads (
  id TEXT PRIMARY KEY,
  public_ref TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  direction TEXT NOT NULL,
  service_id TEXT REFERENCES services(id),
  channel TEXT NOT NULL,
  contact TEXT NOT NULL,
  question TEXT,
  consent INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'new',
  internal_notes TEXT,
  calculation_id TEXT REFERENCES calculations(id),
  ip_hash TEXT,
  user_agent TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX IF NOT EXISTS idx_leads_created ON leads(created_at);

CREATE TABLE IF NOT EXISTS lead_events (
  id TEXT PRIMARY KEY,
  lead_id TEXT NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  from_status TEXT,
  to_status TEXT,
  actor TEXT NOT NULL,
  message TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lead_events_lead ON lead_events(lead_id);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  lead_id TEXT NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  channel TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  payload TEXT,
  created_at TEXT NOT NULL,
  sent_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_notifications_lead ON notifications(lead_id);

CREATE TABLE IF NOT EXISTS knowledge_sources (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  url TEXT,
  publisher TEXT,
  accessed_at TEXT NOT NULL,
  note TEXT
);

CREATE TABLE IF NOT EXISTS knowledge_entries (
  id TEXT PRIMARY KEY,
  domain TEXT NOT NULL,
  key TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  positive TEXT NOT NULL DEFAULT '[]',
  shadow TEXT NOT NULL DEFAULT '[]',
  recommendations TEXT NOT NULL DEFAULT '[]',
  details TEXT NOT NULL DEFAULT '{}',
  methodology TEXT NOT NULL,
  source_id TEXT REFERENCES knowledge_sources(id),
  verified_at TEXT NOT NULL,
  version TEXT NOT NULL,
  UNIQUE(domain, key, methodology)
);

CREATE TABLE IF NOT EXISTS password_resets (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_password_resets_user ON password_resets(user_id);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id TEXT,
  meta TEXT,
  ip TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);

CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  count INTEGER NOT NULL DEFAULT 0,
  window_start INTEGER NOT NULL
);
`;a.s(["S",0,function(a,b,c=[]){return a.prepare(b).all(...c)},"g",0,function(a,b,c=[]){return a.prepare(b).get(...c)},"$",0,function(){let a,f;return globalThis.__astraDb||(globalThis.__astraDb=(a=function(){let a=process.env.DATABASE_PATH?.trim();if(":memory:"===a)return":memory:";let b=a&&a.length>0?a:"./data/app.db",e=d.default.isAbsolute(b)?b:d.default.join(process.cwd(),b);return c.default.mkdirSync(d.default.dirname(e),{recursive:!0}),e}(),(f=new b.DatabaseSync(a)).exec(e),f.function("ru_lower",{deterministic:!0},a=>"string"==typeof a?a.toLocaleLowerCase("ru-RU"):null==a?"":String(a).toLocaleLowerCase("ru-RU")),f)),globalThis.__astraDb},"o",0,function(a,b){if("string"!=typeof a||0===a.length)return b;try{return JSON.parse(a)}catch{return b}},"h",0,function(a,b,c=[]){a.prepare(b).run(...c)}])}];

//# sourceMappingURL=src_lib_db_ts_16pqnef5-fsqp._.js.map