module.exports=[3910,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_astrology_page_actions_151sq5rwe027a.js.map