module.exports=[14699,a=>{"use strict";a.s([])}];

//# sourceMappingURL=1oeh_server_app_specialist_%28cabinet%29_knowledge_page_actions_06q3uk73c67xf.js.map