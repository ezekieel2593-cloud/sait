module.exports=[32243,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_specialist_%28cabinet%29_leads_page_actions_1rveyjqk90kf2.js.map