module.exports=[50751,a=>{"use strict";a.s([])}];

//# sourceMappingURL=1oeh_server_app_specialist_%28cabinet%29_settings_page_actions_0jfm9a2rggpl8.js.map