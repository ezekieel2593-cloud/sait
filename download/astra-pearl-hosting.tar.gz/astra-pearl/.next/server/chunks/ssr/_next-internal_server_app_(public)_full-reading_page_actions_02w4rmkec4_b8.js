module.exports=[42420,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_full-reading_page_actions_02w4rmkec4_b8.js.map