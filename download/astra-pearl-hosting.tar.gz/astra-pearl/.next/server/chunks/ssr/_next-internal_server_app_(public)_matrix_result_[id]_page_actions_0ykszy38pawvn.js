module.exports=[39648,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_matrix_result_%5Bid%5D_page_actions_0ykszy38pawvn.js.map