module.exports=[81004,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_specialist_%28cabinet%29_page_actions_0-31m7bestvm_.js.map