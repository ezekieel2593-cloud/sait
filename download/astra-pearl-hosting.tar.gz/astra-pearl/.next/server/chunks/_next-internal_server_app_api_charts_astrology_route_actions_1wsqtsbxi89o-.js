module.exports=[99277,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_charts_astrology_route_actions_1wsqtsbxi89o-.js.map