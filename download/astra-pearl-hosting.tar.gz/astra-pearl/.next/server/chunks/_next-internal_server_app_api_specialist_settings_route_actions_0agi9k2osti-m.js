module.exports=[23013,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_specialist_settings_route_actions_0agi9k2osti-m.js.map