module.exports=[15700,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_specialist_route_actions_1b1ogownwd_ud.js.map