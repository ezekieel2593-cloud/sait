module.exports=[89104,t=>{"use strict";var i=t.i(43793);function e(t,i){let e=process.env[t],n=e?Number.parseInt(e,10):0/0;return Number.isFinite(n)&&n>0?n:i}t.s(["X",0,{calculations:()=>e("RATE_LIMIT_MAX_CALCULATIONS",30),leads:()=>e("RATE_LIMIT_MAX_LEADS",5),login:()=>e("RATE_LIMIT_MAX_LOGIN",8),windowMs:()=>e("RATE_LIMIT_WINDOW_MS",9e5)},"I",0,function(t,e,n){let r=(0,i.$)(),s=Date.now(),E=s-n;(0,i.h)(r,`INSERT INTO rate_limits (key, count, window_start) VALUES (?, 1, ?)
     ON CONFLICT(key) DO UPDATE SET
       count = CASE WHEN rate_limits.window_start <= ? THEN 1 ELSE rate_limits.count + 1 END,
       window_start = CASE WHEN rate_limits.window_start <= ? THEN ? ELSE rate_limits.window_start END`,[t,s,E,E,s]);let _=(0,i.g)(r,"SELECT count, window_start FROM rate_limits WHERE key = ?",[t]),a=_?.count??1;return{allowed:a<=e,remaining:Math.max(0,e-a),resetAt:(_?.window_start??s)+n}}])}];

//# sourceMappingURL=src_lib_rate-limit_ts_09dzyftcadggh._.js.map