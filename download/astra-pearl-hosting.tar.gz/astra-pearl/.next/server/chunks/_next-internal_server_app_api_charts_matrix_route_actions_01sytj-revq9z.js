module.exports=[20720,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_charts_matrix_route_actions_01sytj-revq9z.js.map