# Как залить на хостинг

В архиве — готовая production-сборка (Next.js standalone) и заполненная база.
Сборка на сервере не нужна: требуются только **Node.js 22.5 или новее**
(используется встроенный модуль `node:sqlite`) и постоянный диск.

## Быстрый старт (VPS, Node.js)

```bash
unzip astra-pearl-1.0.0.zip -d /srv     # содержимое появится в /srv/astra-pearl
cd /srv/astra-pearl

cp .env.example .env
# отредактируйте .env: AUTH_SECRET (openssl rand -hex 32), NEXT_PUBLIC_SITE_URL=https://ваш-домен

node tools/init-db.mjs            # проверка базы и наполнения (можно пропустить: база уже в архиве)
node tools/create-specialist.mjs --email you@example.com --name "Ваше имя" --password 'длинный-пароль'

./start.sh                        # или: PORT=3000 node server.js
```

Сайт: `http://localhost:3000`, кабинет: `/specialist/login`.

Порт задаётся переменной `PORT` (многие PaaS передают её сами).
Перед публикацией поставьте HTTPS-прокси (nginx/Caddy) — cookie сессии в production
передаётся только по HTTPS.

## Что где лежит

| Путь | Назначение |
| --- | --- |
| `server.js`, `.next/`, `node_modules/` | сервер приложения (не переносите по отдельности) |
| `public/` | логотип, OG-картинка, плейсхолдер фото |
| `data/app.db` | база: настройки, услуги, база знаний, заявки, аккаунты |
| `tools/init-db.mjs` | создать схему и наполнить справочники (идемпотентно) |
| `tools/create-specialist.mjs` | создать аккаунт / сменить пароль / список аккаунтов |
| `tools/schema.mjs` | сгенерированная схема и наполнение для init-db |
| `tools/maintenance.mjs` | плановая чистка: обезличивание старых заявок, сессии, лимиты |
| `start.sh` | запуск с чтением `.env` |
| `docs/` | деплой, интеграции, методика, API |

## Обязательные переменные окружения

```env
NODE_ENV=production
NEXT_PUBLIC_SITE_URL=https://ваш-домен
AUTH_SECRET=<openssl rand -hex 32>
DATABASE_PATH=./data/app.db
```

Дополнительно (уведомления о заявках): `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`,
`MAX_BOT_TOKEN`, `MAX_CHAT_ID`, `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD`, `MAIL_FROM`.
Пока они пусты, заявки сохраняются в базе и видны в кабинете, а в журнале уведомлений
стоит статус `skipped` — это нормальное состояние, а не ошибка.

## Хостинг без Node.js

Архив рассчитан на Node-хостинг (VPS, Railway, Render, Timeweb Cloud и т. п.).
На статическом хостинге (GitHub Pages, обычный shared-хостинг без Node) приложение
работать не будет: расчёты, заявки и кабинет выполняются на сервере.

## Обслуживание

```bash
# ежедневно по cron: обезличивание старых заявок, чистка лимитов и сессий
15 4 * * * cd /srv/astra-pearl && node tools/maintenance.mjs >> /var/log/astra-maintenance.log 2>&1
```

## Обновление

1. Сделайте бэкап `data/app.db`.
2. Распакуйте новую версию архива в отдельный каталог.
3. Скопируйте туда свой `data/app.db` и `.env`.
4. Перезапустите сервис.

Схема создаётся через `CREATE TABLE IF NOT EXISTS`, поэтому новая версия работает
со старой базой; при необходимости выполните `node tools/init-db.mjs`.

Подробности, systemd/nginx и резервное копирование — в `docs/DEPLOYMENT.md`.
